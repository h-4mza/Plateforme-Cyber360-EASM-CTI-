import uuid
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, or_, cast, String
from app.models.organization import Organization
from app.models.threat_landscape import ThreatActorProfile, ThreatLandscapeBriefing
from app.models.risk import Risk
from app.models.attack import AttackTechnique
from sqlalchemy import text
from datetime import date
from collections import defaultdict
from app.core.llm_client import call_llm

def get_severity_weight(severity: str) -> float:
    weights = {"critical": 4.0, "high": 3.0, "medium": 2.0, "low": 1.0}
    return weights.get(severity.lower(), 1.0)

async def get_org_active_techniques(db: AsyncSession, org_id: uuid.UUID, domain_id: uuid.UUID | None = None):
    # Retrieve all open risks for the org/domain and their associated techniques
    if domain_id:
        stmt = text("""
            SELECT DISTINCT r.id, r.rule_key, r.severity, rtm.technique_id 
            FROM risks r
            JOIN risk_technique_map rtm ON r.id = rtm.risk_id
            JOIN assets a ON r.asset_id = a.id
            WHERE r.organization_id = :org_id 
              AND a.domain_id = :domain_id 
              AND r.status = 'open'
        """)
        params = {"org_id": str(org_id), "domain_id": str(domain_id)}
    else:
        stmt = text("""
            SELECT DISTINCT r.id, r.rule_key, r.severity, rtm.technique_id 
            FROM risks r
            JOIN risk_technique_map rtm ON r.id = rtm.risk_id
            WHERE r.organization_id = :org_id AND r.status = 'open'
        """)
        params = {"org_id": str(org_id)}
        
    result = await db.execute(stmt, params)
    rows = result.all()
    
    technique_to_risks = defaultdict(list)
    for row in rows:
        technique_to_risks[row.technique_id].append({
            "risk_id": str(row.id),
            "rule_key": row.rule_key,
            "severity": row.severity
        })
    return technique_to_risks

async def get_relevant_threat_actors(db: AsyncSession, org: Organization):
    stmt = select(ThreatActorProfile)
    result = await db.execute(stmt)
    actors = result.scalars().all()
    
    org_sector = (org.sector or "").lower()
    org_country = (org.country or "MA").upper()
    org_regions = [org_country, "MENA", "GLOBAL", "AFRICA"]
    
    relevant = []
    for actor in actors:
        sector_match = False
        if not actor.targeted_sectors or any(s.lower() == org_sector for s in actor.targeted_sectors) or "global" in [s.lower() for s in actor.targeted_sectors]:
            sector_match = True
            
        region_match = False
        if not actor.targeted_regions or any(r.upper() in org_regions for r in actor.targeted_regions):
            region_match = True
            
        if sector_match or region_match:
            relevant.append(actor)
            
    return relevant

async def calculate_threat_landscape_matches(db: AsyncSession, org_id: uuid.UUID, domain_id: uuid.UUID | None = None):
    org = await db.get(Organization, org_id)
    if not org:
        raise ValueError("Organization not found")
        
    technique_to_risks = await get_org_active_techniques(db, org_id, domain_id)
    actors = await get_relevant_threat_actors(db, org)
    
    matches = []
    for actor in actors:
        common_techniques = []
        total_actor_techniques = len(actor.mitre_techniques) if actor.mitre_techniques else 1
        
        severity_score_sum = 0
        
        for tech in actor.mitre_techniques:
            if tech in technique_to_risks:
                active_risks = technique_to_risks[tech]
                common_techniques.append({
                    "technique_id": tech,
                    "active_risks": active_risks
                })
                # Add severity weight for this technique (max severity of its risks)
                max_sev = max((get_severity_weight(r["severity"]) for r in active_risks), default=0)
                severity_score_sum += max_sev
        
        covered_techniques_count = len(common_techniques)
        base_score = covered_techniques_count / total_actor_techniques
        final_score = base_score * severity_score_sum
        
        matches.append({
            "actor_id": str(actor.id),
            "actor_name": actor.name,
            "targeted_sectors": actor.targeted_sectors,
            "targeted_regions": actor.targeted_regions,
            "description": actor.description,
            "source_ref": actor.source_ref,
            "common_techniques": common_techniques,
            "is_active_threat": covered_techniques_count > 0,
            "score": round(final_score, 2),
            "covered_techniques_count": covered_techniques_count,
            "total_techniques_count": total_actor_techniques,
            "severity_score_sum": severity_score_sum
        })
        
    # Sort matches: highest score first
    matches.sort(key=lambda x: x["score"], reverse=True)
    return matches

async def generate_daily_briefing(db: AsyncSession, org_id: uuid.UUID, domain_id: uuid.UUID | None = None) -> ThreatLandscapeBriefing:
    today = date.today()
    
    # Check if a briefing already exists for today and this scope
    if domain_id:
        stmt = select(ThreatLandscapeBriefing).where(
            and_(
                ThreatLandscapeBriefing.organization_id == org_id,
                ThreatLandscapeBriefing.domain_id == domain_id,
                ThreatLandscapeBriefing.briefing_date == today
            )
        )
    else:
        stmt = select(ThreatLandscapeBriefing).where(
            and_(
                ThreatLandscapeBriefing.organization_id == org_id,
                ThreatLandscapeBriefing.domain_id.is_(None),
                ThreatLandscapeBriefing.briefing_date == today
            )
        )
        
    existing = (await db.execute(stmt)).scalar_one_or_none()
    if existing:
        return existing
        
    # Generate new briefing
    matches = await calculate_threat_landscape_matches(db, org_id, domain_id)
    org = await db.get(Organization, org_id)
    
    system_prompt = (
        "Vous êtes un analyste expert en Cyber Threat Intelligence (CTI). "
        "Rédigez un Executive Briefing quotidien sur le paysage de la menace ciblant l'organisation.\n"
        "Règles CRITIQUES :\n"
        "1. Vous devez vous baser UNIQUEMENT sur les correspondances déterministes fournies au format JSON.\n"
        "2. N'inventez aucune donnée, aucun groupe, aucune technique non fournie.\n"
        "3. Rédigez un résumé clair, professionnel, et synthétique (3-4 paragraphes max).\n"
        "4. La réponse DOIT être un JSON valide avec le format exact suivant :\n"
        "{\n"
        '  "executive_summary": "Votre résumé global en texte",\n'
        '  "key_concerns": ["Point 1", "Point 2"],\n'
        '  "recommendations": ["Reco 1", "Reco 2"]\n'
        "}"
    )
    
    # Prepare data for LLM
    clean_matches = []
    for m in matches:
        if m["is_active_threat"]:
            clean_matches.append({
                "actor": m["actor_name"],
                "description": m["description"],
                "active_overlapping_techniques_count": m["covered_techniques_count"]
            })
            
    scope_str = "Vue globale (tous les domaines)" if not domain_id else f"Domaine spécifique (ID: {domain_id})"
    
    user_prompt = f"""
Profil Organisation : Secteur={org.sector}, Pays={org.country}
Scope d'analyse : {scope_str}

Groupes de menaces pertinents ayant des techniques actives communes avec nos vulnérabilités ouvertes :
{clean_matches}

Si la liste est vide, indiquez qu'aucune correspondance directe avec des groupes connus n'est active actuellement.
Rédigez le briefing.
"""

    llm_res = await call_llm(system_prompt, user_prompt, max_tokens=1000)
    
    import json
    try:
        content_json = json.loads(llm_res["text"])
    except json.JSONDecodeError:
        content_json = {
            "executive_summary": "Erreur de formatage de la réponse LLM. Voici la réponse brute : " + llm_res["text"],
            "key_concerns": [],
            "recommendations": []
        }
        
    briefing = ThreatLandscapeBriefing(
        organization_id=org_id,
        domain_id=domain_id,
        briefing_date=today,
        content=content_json,
        generated_by="llm"
    )
    db.add(briefing)
    await db.commit()
    await db.refresh(briefing)
    
    return briefing
