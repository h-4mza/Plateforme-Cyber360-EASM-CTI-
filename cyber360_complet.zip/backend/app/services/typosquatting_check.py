import asyncio
import json
import subprocess
import sys
import httpx
import re
import difflib
import uuid
import logging
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.models.domain import Domain
from app.models.asset import Asset
from app.models.risk import Risk, RiskSeverity

logger = logging.getLogger(__name__)

async def fetch_html(url: str, timeout=5):
    try:
        async with httpx.AsyncClient(verify=False, timeout=timeout) as client:
            resp = await client.get(url)
            return resp.text, resp.status_code
    except Exception:
        return "", 0

def extract_text(html: str):
    if not html:
        return "", ""
    
    # extract title
    title_match = re.search(r'<title[^>]*>([^<]+)</title>', html, re.IGNORECASE)
    title = title_match.group(1).strip() if title_match else ""
    
    # extract body text roughly (remove scripts, styles, and tags)
    body = re.sub(r'<script[^>]*>.*?</script>', ' ', html, flags=re.IGNORECASE | re.DOTALL)
    body = re.sub(r'<style[^>]*>.*?</style>', ' ', body, flags=re.IGNORECASE | re.DOTALL)
    text = re.sub(r'<[^>]+>', ' ', body)
    text = " ".join(text.split())
    
    return title.lower(), text.lower()

async def analyze_similarity(legit_html: str, squat_html: str):
    legit_title, legit_text = extract_text(legit_html)
    squat_title, squat_text = extract_text(squat_html)
    
    if not squat_text:
        return 0.0
        
    # Title similarity is a strong indicator
    title_sim = difflib.SequenceMatcher(None, legit_title, squat_title).ratio() if legit_title else 0
    text_sim = difflib.SequenceMatcher(None, legit_text[:2000], squat_text[:2000]).ratio()
    
    return max(title_sim, text_sim)

async def check_typosquatting_for_domain(domain: Domain, db: AsyncSession):
    # 1. Get root asset
    stmt = select(Asset).where(Asset.domain_id == str(domain.id), Asset.hostname == domain.name, Asset.type == "root_domain")
    root_asset = (await db.execute(stmt)).scalars().first()
    if not root_asset:
        logger.warning(f"No root asset found for domain {domain.name}")
        return

    # 2. Fetch legit domain content
    legit_html, _ = await fetch_html(f"http://{domain.name}")
    if not legit_html:
        legit_html, _ = await fetch_html(f"https://{domain.name}")

    # 3. Run dnstwist (registered only)
    def _run_dnstwist(dname):
        result = subprocess.run(
            [sys.executable, "-m", "dnstwist", "--registered", "--format", "json", dname],
            capture_output=True, text=True
        )
        if result.returncode == 0 and result.stdout.strip():
            return json.loads(result.stdout)
        return []

    logger.info(f"Running dnstwist for {domain.name}")
    results = await asyncio.to_thread(_run_dnstwist, domain.name)
    
    for r in results:
        fuzzed_name = r.get("domain", "")
        if fuzzed_name == domain.name:
            continue
            
        dns_a = r.get("dns_a", [])
        if not dns_a:
            continue # Needs an active IP

        # 4. Check TLS/HTTP and similarity
        squat_html_http, status_http = await fetch_html(f"http://{fuzzed_name}")
        squat_html_https, status_https = await fetch_html(f"https://{fuzzed_name}")
        
        has_web = status_http > 0 or status_https > 0
        has_tls = status_https > 0
        
        best_squat_html = squat_html_https if squat_html_https else squat_html_http
        
        similarity = 0.0
        if has_web and legit_html:
            similarity = await analyze_similarity(legit_html, best_squat_html)
            
        # Ignore obvious parking or completely different pages if similarity is very low, unless it's a known technique
        # Wait, parking pages might have similarity = 0. We still flag them but with medium/low severity.
        # If similarity > 0.6, it's a high severity mimic!
        
        severity = RiskSeverity.medium
        if has_web and similarity > 0.5:
            severity = RiskSeverity.critical
        elif has_tls:
            severity = RiskSeverity.high # squatter took the time to set up TLS
            
        evidence = {
            "squatted_domain": fuzzed_name,
            "dns_a": dns_a,
            "fuzzer": r.get("fuzzer", "unknown"),
            "has_web": has_web,
            "has_tls": has_tls,
            "similarity_score": round(similarity, 2)
        }
        
        # Check if risk already exists
        stmt_risk = select(Risk).where(
            Risk.asset_id == root_asset.id,
            Risk.rule_key == "typosquatting_detected",
            Risk.details.op('->>')('squatted_domain') == fuzzed_name
        )
        existing_risk = (await db.execute(stmt_risk)).scalar_one_or_none()
        
        if existing_risk:
            existing_risk.severity = severity
            existing_risk.details = evidence
            existing_risk.status = "open"
        else:
            new_risk = Risk(
                id=uuid.uuid4(),
                organization_id=domain.organization_id,
                asset_id=root_asset.id,
                rule_key="typosquatting_detected",
                severity=severity,
                status="open",
                details=evidence
            )
            db.add(new_risk)
            
    await db.commit()
