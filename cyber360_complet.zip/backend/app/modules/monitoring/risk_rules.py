from typing import Dict, Any, Callable, List, Tuple, Optional
from app.models.check import CheckResult

RULES_REGISTRY: Dict[str, Dict[str, Any]] = {}

def rule(key: str, check_types: List[str]):
    def decorator(func):
        RULES_REGISTRY[key] = {
            "check_types": check_types,
            "evaluator": func
        }
        return func
    return decorator

# --- Messagerie (DNS) ---
@rule("spf_missing", ["spf"])
def evaluate_spf_missing(check_type: str, result: CheckResult, details: Dict[str, Any], asset) -> Tuple[bool, Optional[str]]:
    return "SPF absent" in details.get("info", ""), None

@rule("spf_permissive", ["spf"])
def evaluate_spf_permissive(check_type: str, result: CheckResult, details: Dict[str, Any], asset) -> Tuple[bool, Optional[str]]:
    return "+all" in details.get("info", ""), None

@rule("spf_softfail", ["spf"])
def evaluate_spf_softfail(check_type: str, result: CheckResult, details: Dict[str, Any], asset) -> Tuple[bool, Optional[str]]:
    return "~all" in details.get("info", ""), None

@rule("dmarc_missing", ["dmarc"])
def evaluate_dmarc_missing(check_type: str, result: CheckResult, details: Dict[str, Any], asset) -> Tuple[bool, Optional[str]]:
    return "DMARC absent" in details.get("info", ""), None

@rule("dmarc_none", ["dmarc"])
def evaluate_dmarc_none(check_type: str, result: CheckResult, details: Dict[str, Any], asset) -> Tuple[bool, Optional[str]]:
    return "p=none" in details.get("info", ""), None

@rule("dkim_missing", ["dkim"])
def evaluate_dkim_missing(check_type: str, result: CheckResult, details: Dict[str, Any], asset) -> Tuple[bool, Optional[str]]:
    return "Aucun enregistrement DKIM détecté" in details.get("info", ""), None

@rule("dnssec_missing", ["dnssec"])
def evaluate_dnssec_missing(check_type: str, result: CheckResult, details: Dict[str, Any], asset) -> Tuple[bool, Optional[str]]:
    return "Aucune clé DNSSEC" in details.get("info", ""), None

@rule("mta_sts_missing", ["mta_sts"])
def evaluate_mta_sts_missing(check_type: str, result: CheckResult, details: Dict[str, Any], asset) -> Tuple[bool, Optional[str]]:
    info = details.get("info", "")
    return "MTA-STS absent" in info or "MTA-STS TXT présent mais politique" in info, None

@rule("tls_rpt_missing", ["tls_rpt"])
def evaluate_tls_rpt_missing(check_type: str, result: CheckResult, details: Dict[str, Any], asset) -> Tuple[bool, Optional[str]]:
    return "TLS-RPT absent" in details.get("info", ""), None

# --- TLS ---
@rule("tls_old_version", ["tls"])
def evaluate_tls_old_version(check_type: str, result: CheckResult, details: Dict[str, Any], asset) -> Tuple[bool, Optional[str]]:
    return "Obsolescent TLS version" in details.get("error", ""), None

@rule("tls_cert_expired", ["tls"])
def evaluate_tls_cert_expired(check_type: str, result: CheckResult, details: Dict[str, Any], asset) -> Tuple[bool, Optional[str]]:
    return (asset and asset.cert_status == "Critique"), None

@rule("tls_cert_expiring_soon", ["tls"])
def evaluate_tls_cert_expiring_soon(check_type: str, result: CheckResult, details: Dict[str, Any], asset) -> Tuple[bool, Optional[str]]:
    # Dynamic severity based on cert_status
    if asset and asset.cert_status:
        if asset.cert_status == "Important":
            return True, "high"
        elif asset.cert_status == "Moyen":
            return True, "medium"
    return False, None

@rule("caa_missing", ["caa"])
def evaluate_caa_missing(check_type: str, result: CheckResult, details: Dict[str, Any], asset) -> Tuple[bool, Optional[str]]:
    return "CAA absent" in details.get("info", ""), None

# --- HTTP Headers ---
@rule("http_no_redirect", ["http_headers"])
def evaluate_http_no_redirect(check_type: str, result: CheckResult, details: Dict[str, Any], asset) -> Tuple[bool, Optional[str]]:
    return (asset and asset.http_redirect_status == "Non conforme"), None

@rule("hsts_missing", ["http_headers"])
def evaluate_hsts_missing(check_type: str, result: CheckResult, details: Dict[str, Any], asset) -> Tuple[bool, Optional[str]]:
    return "hsts" in details and not details["hsts"], None

@rule("csp_missing", ["http_headers"])
def evaluate_csp_missing(check_type: str, result: CheckResult, details: Dict[str, Any], asset) -> Tuple[bool, Optional[str]]:
    return "csp" in details and not details["csp"], None

@rule("x_frame_options_missing", ["http_headers"])
def evaluate_x_frame_options_missing(check_type: str, result: CheckResult, details: Dict[str, Any], asset) -> Tuple[bool, Optional[str]]:
    return "x_frame_options" in details and not details["x_frame_options"], None

# --- Services ---
@rule("admin_port_exposed", ["ports"])
def evaluate_admin_port_exposed(check_type: str, result: CheckResult, details: Dict[str, Any], asset) -> Tuple[bool, Optional[str]]:
    open_ports = details.get("open_ports", [])
    if 22 in open_ports or 3389 in open_ports:
        if asset and asset.criticality == "high":
            return True, "critical"
        elif asset and asset.criticality == "medium":
            return True, "high"
        else:
            return True, "medium"
    return False, None

@rule("mail_port_exposed_without_tls", ["ports"])
def evaluate_mail_port_exposed_without_tls(check_type: str, result: CheckResult, details: Dict[str, Any], asset) -> Tuple[bool, Optional[str]]:
    open_ports = details.get("open_ports", [])
    return 25 in open_ports, None

@rule("eol_software_detected", ["tls", "http_headers"])
def evaluate_eol_software_detected(check_type: str, result: CheckResult, details: Dict[str, Any], asset) -> Tuple[bool, Optional[str]]:
    return (asset and asset.is_eol), None
