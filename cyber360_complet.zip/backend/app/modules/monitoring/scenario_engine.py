import json
import os
import logging
import copy
from collections import deque
from datetime import datetime, timezone
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import Dict, Any, List

from app.models.risk import Risk
from app.models.asset import Asset
from app.models.asset_relation import AssetRelation
from app.models.attack_scenario import AttackScenarioDetected

# --- Scoring Constants ---
# Severity Weighting: Later stages carry more weight as they are closer to impact.
# We'll use a linear multiplier based on stage index.
SEVERITY_BASE_WEIGHT = 1.0
SEVERITY_STAGE_MULTIPLIER = 0.5 

# Likelihood Weighting
WEIGHT_COMPLETENESS = 0.40
WEIGHT_CONFIDENCE = 0.25
WEIGHT_FRESHNESS = 0.15
WEIGHT_THREAT_RELEVANCE = 0.20

# Freshness decay half-life in days
FRESHNESS_HALF_LIFE_DAYS = 30.0
# -------------------------

def load_attack_scenarios() -> Dict[str, Any]:
    filepath = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))), "attack_scenarios.json")
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        print(f"Error loading scenarios: {e}")
        return {}

def get_reachable_assets(start_asset_id, graph, max_hops, allowed_relation_types):
    if max_hops == 0:
        return {start_asset_id}
        
    reachable = {start_asset_id}
    queue = deque([(start_asset_id, 0)])
    
    while queue:
        current_id, hops = queue.popleft()
        if hops >= max_hops:
            continue
            
        for neighbor, rel_type, confidence in graph.get(current_id, []):
            if allowed_relation_types and rel_type not in allowed_relation_types:
                continue
            if neighbor not in reachable:
                reachable.add(neighbor)
                queue.append((neighbor, hops + 1))
                
    return reachable

def calculate_scenario_scores(best_path: dict, total_stages: int, open_risks: List[Risk], graph: dict):
    """
    Calcule le severity_score et likelihood_score pour le chemin d'attaque détecté.
    
    severity_score: Moyenne pondérée de la sévérité des risques, avec poids croissant par étape.
    likelihood_score: Combinaison de:
      - Complétude (40%)
      - Confiance moyenne des arêtes (25%)
      - Fraîcheur des risques (15%)
      - Pertinence de la menace (20%) [Mocké ici pour l'intégration ATT&CK]
    """
    import math
    
    # Récupérer les objets Risk complets impliqués
    path_risks = [r for r in open_risks if str(r.id) in best_path["risk_ids"]]
    
    # --- 1. Severity Score ---
    severity_map = {"critical": 100, "high": 80, "medium": 50, "low": 20, "info": 0}
    total_sev_weight = 0
    weighted_sev_sum = 0
    
    oldest_risk_date = datetime.now(timezone.utc)
    
    for item in best_path["path"]:
        stage = item["stage"]
        risk_id = item["risk_id"]
        r_obj = next((r for r in path_risks if str(r.id) == risk_id), None)
        
        if r_obj:
            sev_val = severity_map.get(r_obj.severity.value if hasattr(r_obj.severity, 'value') else r_obj.severity, 50)
            weight = SEVERITY_BASE_WEIGHT + (stage * SEVERITY_STAGE_MULTIPLIER)
            weighted_sev_sum += sev_val * weight
            total_sev_weight += weight
            
            r_created = r_obj.created_at
            if r_created:
                if r_created.tzinfo is None:
                    r_created = r_created.replace(tzinfo=timezone.utc)
                if r_created < oldest_risk_date:
                    oldest_risk_date = r_created

    severity_score = int(weighted_sev_sum / total_sev_weight) if total_sev_weight > 0 else 0
    
    # --- 2. Likelihood Score ---
    stage_reached = best_path["stages_completed"]
    score_completeness = (stage_reached / total_stages) * 100.0
    
    # Confiance moyenne des arêtes (si applicable)
    # Pour simplifier, on prend 100% si c'est sur le même actif, sinon on cherche l'arête
    score_confidence = 100.0
    edges_confidence = []
    path_nodes = [item["asset_id"] for item in best_path["path"]]
    for i in range(len(path_nodes) - 1):
        u = path_nodes[i]
        v = path_nodes[i+1]
        if u == v:
            edges_confidence.append(1.0)
        else:
            # Chercher la confiance de l'arête dans le graphe
            conf = 0.5 # fallback
            for neighbor, rtype, c in graph.get(u, []):
                if neighbor == v:
                    conf = c
                    break
            edges_confidence.append(conf)
            
    if edges_confidence:
        score_confidence = (sum(edges_confidence) / len(edges_confidence)) * 100.0
        
    # Fraîcheur
    days_old = (datetime.now(timezone.utc) - oldest_risk_date).days
    decay_factor = math.exp(-0.693 * (days_old / FRESHNESS_HALF_LIFE_DAYS)) # demi-vie
    score_freshness = decay_factor * 100.0
    
    # Menace réelle (Intégration ATT&CK théorique / stub)
    # En réalité, on appellerait `compute_group_exposure` ici.
    # Pour cet exemple, on simule un score basé sur le nombre de techniques mappées.
    mapped_techs = [item["technique_id"] for item in best_path["path"] if item.get("technique_id")]
    score_threat = min(len(mapped_techs) * 25.0, 100.0) # 25 points par technique
    relevant_groups = ["APT29"] if mapped_techs else [] # Mock
    
    likelihood_score = int(
        (score_completeness * WEIGHT_COMPLETENESS) +
        (score_confidence * WEIGHT_CONFIDENCE) +
        (score_freshness * WEIGHT_FRESHNESS) +
        (score_threat * WEIGHT_THREAT_RELEVANCE)
    )
    
    return severity_score, likelihood_score, relevant_groups

async def evaluate_organization_scenarios(org_id: str, db: AsyncSession):
    scenarios = load_attack_scenarios()
    if not scenarios:
        return

    # Load all open risks for this organization
    stmt = select(Risk).where(Risk.organization_id == org_id, Risk.status == "open")
    result = await db.execute(stmt)
    open_risks = result.scalars().all()

    risks_by_asset = {}
    for r in open_risks:
        if r.asset_id not in risks_by_asset:
            risks_by_asset[r.asset_id] = []
        risks_by_asset[r.asset_id].append(r)

    # Load all assets for the org to get relations
    stmt_assets = select(Asset.id).where(Asset.organization_id == org_id)
    org_asset_ids = [str(a) for a in (await db.execute(stmt_assets)).scalars().all()]
    
    # Load all asset relations where source is in the org's assets
    graph = {}
    if org_asset_ids:
        # For a production system with millions of relations, we'd chunk this.
        stmt_rels = select(AssetRelation)
        # Using a simple fetch all since we assume the service runs on a moderate number of relations,
        # but to be completely safe we filter by org's assets.
        # However, since we're in async and in-memory O(N) is requested, we fetch relations for the org
        # To avoid complex IN clauses if there are many assets, we fetch all relations where source is in org_asset_ids
        pass
        
    # Let's just fetch all relations where source or target is in org_asset_ids.
    # Since we can't easily do an OR on large arrays, and this is for the whole org,
    # let's just fetch all relations where source is an asset from this org.
    stmt_rels = select(AssetRelation).join(Asset, AssetRelation.source_asset_id == Asset.id).where(Asset.organization_id == org_id)
    result_rels = await db.execute(stmt_rels)
    relations = result_rels.scalars().all()
    
    for rel in relations:
        src = str(rel.source_asset_id)
        tgt = str(rel.target_asset_id)
        rtype = rel.relation_type.value
        conf = rel.confidence
        
        if src not in graph:
            graph[src] = []
        graph[src].append((tgt, rtype, conf))
        # Assuming undirected/bidirectional traversal for pivoting unless specified otherwise
        if tgt not in graph:
            graph[tgt] = []
        graph[tgt].append((src, rtype, conf))

    # Load existing scenarios for this organization
    stmt_existing = select(AttackScenarioDetected).where(AttackScenarioDetected.organization_id == org_id)
    result_existing = await db.execute(stmt_existing)
    existing_scenarios = {s.scenario_key: s for s in result_existing.scalars().all()}

    now = datetime.now(timezone.utc)

    for scenario_key, s_data in scenarios.items():
        kill_chain = s_data.get("kill_chain", [])
        max_hops = s_data.get("max_hops", 1)
        allowed_relation_types = s_data.get("allowed_relation_types", [])
        
        if not kill_chain:
            continue
            
        total_stages = len(kill_chain)
        
        # paths: list of dicts: {"current_asset_id": str, "stages_completed": int, "path": list, "risk_ids": list}
        active_paths = []
        
        # Stage 1
        stage_1 = kill_chain[0]
        rule_keys_1 = stage_1.get("rule_keys", [])
        
        print(f"[DIAGNOSTIC] Evaluating scenario: {scenario_key}")
        stage_1_risks = []
        for asset_id_str, asset_risks in risks_by_asset.items():
            asset_id = str(asset_id_str)
            matching_risks = [r for r in asset_risks if r.rule_key in rule_keys_1]
            for r in matching_risks:
                stage_1_risks.append({
                    "risk": r,
                    "asset_id": asset_id,
                    "tech_ref": stage_1.get("technique_refs", [""])[0] if stage_1.get("technique_refs") else ""
                })
        
        for item in stage_1_risks:
            r = item["risk"]
            asset_id = item["asset_id"]
            tech_ref = item["tech_ref"]
            
            initial_path = {
                "current_asset_id": asset_id,
                "stages_completed": 1,
                "path": [{"stage": 1, "asset_id": asset_id, "risk_id": str(r.id), "technique_id": tech_ref}],
                "risk_ids": [str(r.id)]
            }
            print(f"  [DIAGNOSTIC] Stage 1 matched for {scenario_key} on asset {asset_id} with rule {r.rule_key}")
            active_paths.append(initial_path)
            
        print(f"  [DIAGNOSTIC] Initial active paths: {len(active_paths)}")
                
        # Subsequent stages
        for stage_idx in range(1, total_stages):
            stage_def = kill_chain[stage_idx]
            rule_keys = stage_def.get("rule_keys", [])
            require_same_asset = stage_def.get("require_same_asset", False)
            
            new_paths = []
            dropped_paths = []
            
            for p in active_paths:
                if p["stages_completed"] != stage_idx:
                    continue
                    
                reachable = set()
                if require_same_asset:
                    reachable.add(p["current_asset_id"])
                else:
                    reachable = get_reachable_assets(p["current_asset_id"], graph, max_hops, allowed_relation_types)
                    
                stage_matched = False
                for target_asset_id in reachable:
                    target_risks = risks_by_asset.get(uuid_str_to_uuid(target_asset_id), [])
                    matching_risks = [r for r in target_risks if r.rule_key in rule_keys]
                    if matching_risks:
                        r = matching_risks[0]
                        tech_ref = stage_def.get("technique_refs", [""])[0] if stage_def.get("technique_refs") else ""
                        
                        next_asset = target_asset_id
                        if next_asset:
                            new_path_obj = copy.deepcopy(p)
                            new_path_obj["current_asset_id"] = next_asset
                            new_path_obj["stages_completed"] = stage_idx + 1
                            new_path_obj["path"].append({"stage": stage_idx + 1, "asset_id": next_asset, "risk_id": str(r.id), "technique_id": tech_ref})
                            new_path_obj["risk_ids"].append(str(r.id))
                            new_paths.append(new_path_obj)
                            stage_matched = True
                            print(f"    [DIAGNOSTIC] Pivot Stage {stage_idx + 1} matched on asset {next_asset} for scenario {scenario_key}")
                
                if not stage_matched:
                    print(f"    [DIAGNOSTIC] Path dropped at Stage {stage_idx + 1} for scenario {scenario_key}")
                    new_paths.append(p)
                    
            active_paths = new_paths
            
        # Determine best path for this scenario
        if not active_paths:
            # Not even stage 1 was reached
            if scenario_key in existing_scenarios:
                scenario_obj = existing_scenarios[scenario_key]
                if scenario_obj.status in ["open", "partial"]:
                    scenario_obj.status = "resolved"
                    scenario_obj.resolved_at = now
            continue
            
        # Find the path that went the furthest
        best_path = max(active_paths, key=lambda p: p["stages_completed"])
        stage_reached = best_path["stages_completed"]
        
        status = "open" if stage_reached == total_stages else "partial"
        
        sev_score, like_score, rel_groups = calculate_scenario_scores(best_path, total_stages, open_risks, graph)
        
        if scenario_key in existing_scenarios:
            scenario_obj = existing_scenarios[scenario_key]
            scenario_obj.status = status
            scenario_obj.risk_ids = list(set(best_path["risk_ids"]))
            scenario_obj.kill_chain_stage_reached = stage_reached
            scenario_obj.kill_chain_total_stages = total_stages
            scenario_obj.attack_path = best_path["path"]
            scenario_obj.severity_score = sev_score
            scenario_obj.likelihood_score = like_score
            scenario_obj.relevant_attack_groups = rel_groups
            scenario_obj.resolved_at = None
        else:
            new_scenario = AttackScenarioDetected(
                organization_id=org_id,
                scenario_key=scenario_key,
                status=status,
                risk_ids=list(set(best_path["risk_ids"])),
                kill_chain_stage_reached=stage_reached,
                kill_chain_total_stages=total_stages,
                attack_path=best_path["path"],
                severity_score=sev_score,
                likelihood_score=like_score,
                relevant_attack_groups=rel_groups
            )
            db.add(new_scenario)
            existing_scenarios[scenario_key] = new_scenario

    await db.commit()

import uuid
def uuid_str_to_uuid(uuid_str):
    if isinstance(uuid_str, uuid.UUID):
        return uuid_str
    try:
        return uuid.UUID(uuid_str)
    except:
        return uuid_str
