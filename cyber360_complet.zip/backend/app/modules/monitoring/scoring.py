import json
import uuid
import os
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from typing import Dict, Any, List

from app.models.risk import Risk, RiskStatus
from app.models.asset import Asset
from app.models.check import Check

def load_scoring_config() -> Dict[str, Any]:
    base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
    path = os.path.join(base_dir, 'risk_scoring_config.json')
    if not os.path.exists(path):
        return {
            "penalties": {"critical": 25, "high": 15, "medium": 8, "low": 3},
            "category_weights": {"dns": 1.0, "tls": 1.0, "messagerie": 1.0, "services": 1.0, "configuration": 1.0}
        }
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)

def load_risk_rules() -> Dict[str, Any]:
    base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
    path = os.path.join(base_dir, 'risk_rules_content.json')
    if not os.path.exists(path):
        return {}
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)

async def compute_score(session: AsyncSession, organization_id: uuid.UUID, domain_id: uuid.UUID = None) -> dict:
    from app.models.domain import Domain
    
    if domain_id:
        assets_count = await session.scalar(select(func.count(Asset.id)).where(Asset.domain_id == domain_id))
        checks_count = await session.scalar(select(func.count(Check.id)).join(Asset).where(Asset.domain_id == domain_id))
        risks = (await session.execute(
            select(Risk).join(Asset).where(Asset.domain_id == domain_id, Risk.status == RiskStatus.open)
        )).scalars().all()
    else:
        assets_count = await session.scalar(
            select(func.count(Asset.id)).join(Domain).where(Asset.organization_id == organization_id, Domain.relationship == 'own')
        )
        checks_count = await session.scalar(
            select(func.count(Check.id)).join(Asset).join(Domain, Asset.domain_id == Domain.id).where(Check.organization_id == organization_id, Domain.relationship == 'own')
        )
        risks = (await session.execute(
            select(Risk).join(Asset).join(Domain, Asset.domain_id == Domain.id).where(
                Risk.organization_id == organization_id, 
                Risk.status == RiskStatus.open,
                Domain.relationship == 'own'
            )
        )).scalars().all()
    
    if not assets_count or not checks_count:
        return {
            "is_available": False,
            "global_score": None,
            "categories": None,
            "message": "Score non disponible : aucun actif ou aucun contrôle n'a encore été exécuté."
        }
        
    config = load_scoring_config()
    rules = load_risk_rules()
    
    penalties_by_severity = config.get("penalties", {})
    weights_by_category = config.get("category_weights", {})
    
    # Initialize dynamic categories from rules and config
    category_penalties: Dict[str, int] = {}
    
    # Get all categories from rules
    for rule_info in rules.values():
        cat = rule_info.get("category")
        if cat and cat not in category_penalties:
            category_penalties[cat] = 0
            
    # Include any remaining categories from config
    for cat in weights_by_category.keys():
        if cat not in category_penalties:
            category_penalties[cat] = 0
    
    for r in risks:
        rule_info = rules.get(r.rule_key)
        if not rule_info:
            continue
        category = rule_info.get("category", "unknown")
        severity = r.severity.value if hasattr(r.severity, "value") else str(r.severity)
        
        penalty = penalties_by_severity.get(severity, 0)
        
        if category in category_penalties:
            category_penalties[category] += penalty
        else:
            category_penalties[category] = penalty
            
    categories_res = []
    total_weight = 0.0
    weighted_score_sum = 0.0
    
    for cat, penalty in category_penalties.items():
        score = max(0, 100 - penalty)
        weight = weights_by_category.get(cat, 1.0)
        
        categories_res.append({
            "category": cat,
            "score": score,
            "weight": weight
        })
        
        weighted_score_sum += score * weight
        total_weight += weight
        
    global_score = int(round(weighted_score_sum / total_weight)) if total_weight > 0 else 100
    
    return {
        "is_available": True,
        "global_score": global_score,
        "categories": categories_res
    }
