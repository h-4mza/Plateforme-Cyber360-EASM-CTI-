import json
import os
from typing import Dict, Any
from datetime import datetime, timezone
from sqlalchemy import select
from app.models.risk import Risk, RiskStatus
from app.models.check import CheckResult
from app.modules.monitoring.risk_rules import RULES_REGISTRY

RISK_RULES_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))), "risk_rules_content.json")
import yaml
import logging

logger = logging.getLogger(__name__)

RISK_RULES_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))), "risk_rules_content.json")
MAPPING_FILE = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "config", "technique_mapping.yaml")

def load_risk_configs():
    with open(RISK_RULES_PATH, "r") as f:
        return json.load(f)

_mapping_cache = None
_mapping_mtime = 0

def get_technique_mapping():
    global _mapping_cache, _mapping_mtime
    if not os.path.exists(MAPPING_FILE):
        return {}
    
    mtime = os.path.getmtime(MAPPING_FILE)
    if _mapping_cache is None or mtime > _mapping_mtime:
        try:
            with open(MAPPING_FILE, "r", encoding="utf-8") as f:
                _mapping_cache = yaml.safe_load(f) or {}
            _mapping_mtime = mtime
        except Exception:
            if _mapping_cache is None:
                _mapping_cache = {}
    return _mapping_cache

async def map_risk_to_techniques(session, risk_id, rule_key):
    mapping = get_technique_mapping()
    techniques = mapping.get(rule_key)
    if not techniques:
        logger.warning(f"No ATT&CK technique mapping found for check type/rule key: {rule_key}")
        return
        
    from sqlalchemy.dialects.postgresql import insert
    from app.models.risk import risk_technique_map
    values = [{"risk_id": risk_id, "technique_id": t} for t in techniques]
    stmt = insert(risk_technique_map).values(values).on_conflict_do_nothing()
    await session.execute(stmt)

async def evaluate_and_update_risks(session, asset, check_type: str, result: CheckResult, details: Dict[str, Any]):
    # Do not evaluate rules if the check failed due to network issues
    if result == CheckResult.error:
        return
        
    try:
        rule_configs = load_risk_configs()
    except Exception:
        return # Skip if file missing in testing environment without proper setup
        
    now_utc = datetime.now(timezone.utc)
    
    for rule_key, rule_meta in RULES_REGISTRY.items():
        if check_type not in rule_meta["check_types"]:
            continue
            
        rule_func = rule_meta["evaluator"]
        try:
            is_triggered, dynamic_severity = rule_func(check_type, result, details, asset)
        except Exception:
            continue
            
        config = rule_configs.get(rule_key, {})
        if not config:
            continue
            
        stmt = select(Risk).where(
            Risk.asset_id == asset.id,
            Risk.rule_key == rule_key
        )
        existing_risk = (await session.execute(stmt)).scalar_one_or_none()
        
        if is_triggered:
            new_severity = dynamic_severity or config.get("default_severity", "medium")
            if existing_risk:
                if existing_risk.status == RiskStatus.resolved:
                    existing_risk.status = RiskStatus.open
                    existing_risk.resolved_at = None
                existing_risk.last_seen_at = now_utc
                if existing_risk.severity != new_severity:
                    existing_risk.severity = new_severity
                existing_risk.details = details
                session.add(existing_risk)
                await session.flush()
                await map_risk_to_techniques(session, existing_risk.id, rule_key)
            else:
                new_risk = Risk(
                    organization_id=asset.organization_id,
                    asset_id=asset.id,
                    rule_key=rule_key,
                    severity=new_severity,
                    status=RiskStatus.open,
                    first_detected_at=now_utc,
                    last_seen_at=now_utc,
                    details=details
                )
                session.add(new_risk)
                await session.flush()
                await map_risk_to_techniques(session, new_risk.id, rule_key)
        else:
            if existing_risk and existing_risk.status == RiskStatus.open:
                existing_risk.status = RiskStatus.resolved
                existing_risk.resolved_at = now_utc

async def evaluate_risk(session, asset_id: str, rule_key: str, is_vulnerable: bool, severity: str, details: Dict[str, Any] = None):
    from app.models.asset import Asset
    now_utc = datetime.now(timezone.utc)
    
    asset = (await session.execute(select(Asset).where(Asset.id == asset_id))).scalar_one_or_none()
    if not asset:
        return
        
    stmt = select(Risk).where(
        Risk.asset_id == asset.id,
        Risk.rule_key == rule_key
    )
    existing_risk = (await session.execute(stmt)).scalar_one_or_none()
    
    if is_vulnerable:
        if existing_risk:
            if existing_risk.status == RiskStatus.resolved:
                existing_risk.status = RiskStatus.open
                existing_risk.resolved_at = None
            existing_risk.last_seen_at = now_utc
            if existing_risk.severity != severity:
                existing_risk.severity = severity
            existing_risk.details = details
            session.add(existing_risk)
            await session.flush()
            await map_risk_to_techniques(session, existing_risk.id, rule_key)
        else:
            new_risk = Risk(
                organization_id=asset.organization_id,
                asset_id=asset.id,
                rule_key=rule_key,
                severity=severity,
                status=RiskStatus.open,
                first_detected_at=now_utc,
                last_seen_at=now_utc,
                details=details
            )
            session.add(new_risk)
            await session.flush()
            await map_risk_to_techniques(session, new_risk.id, rule_key)
    else:
        if existing_risk and existing_risk.status == RiskStatus.open:
            existing_risk.status = RiskStatus.resolved
            existing_risk.resolved_at = now_utc
